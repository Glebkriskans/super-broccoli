﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp7.ApplicationData
{
    class AppData
    {
        public static user7Entities db = new user7Entities();
    }
}
