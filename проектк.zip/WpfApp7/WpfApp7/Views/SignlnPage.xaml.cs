﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp7.ApplicationData;

namespace WpfApp7.Views
{
    /// <summary>
    /// Логика взаимодействия для SignlnPage.xaml
    /// </summary>
    public partial class SignlnPage : Page
    {
        public SignlnPage()
        {
            InitializeComponent();
        }

        private void BtnSignIn_Click(object sender, RoutedEventArgs e)
        {
            var CurrenUser = AppData.db.User1.FirstOrDefault(u => u.Login == TxbLogin.Text && u.Password == TxbPassword.Text);

            //if (CurrenUser != null)
            //{
            //    NavigationService.Navigate(new WelcomePage());
            //}
            //else
            //{
            //    MessageBox.Show("данного пользователя нет в базе данных");
            //}

            var CurrentRole = AppData.db.Role.FirstOrDefault();
            if (CurrentRole == null)
            {
                MessageBox.Show("Данного пользователч нет а базе данных");
            }
            else
            {
                switch (CurrenUser.ID)
                {
                    case 1:NavigationService.Navigate(new WelcomePageAdmin());
                        break;

                    case 2:NavigationService.Navigate(new WelcomePage());
                        break;

                    default: MessageBox.Show("Данных нет");
                        break;
                }
            }
        }
    }
}
